package com.cg.hotelmanagement.controller;

import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hotelmanagement.dto.Booking;
import com.cg.hotelmanagement.dto.City;
import com.cg.hotelmanagement.dto.Customer;
import com.cg.hotelmanagement.dto.Hotel;
import com.cg.hotelmanagement.dto.Room;
import com.cg.hotelmanagement.exception.HotelException;
import com.cg.hotelmanagement.repository.BookingRepository;
import com.cg.hotelmanagement.repository.CustomerRepository;
import com.cg.hotelmanagement.service.IAdminService;
import com.cg.hotelmanagement.service.ICustomerService;
import com.cg.hotelmanagement.service.Validate;

/*
 * Author : Avantika Singh
 */

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {

	@Autowired
	ICustomerService customerService;
	@Autowired
	IAdminService adminService;
	@Autowired
	HttpSession session;
	@Autowired
	CustomerRepository customerRepo;
	@Autowired
	BookingRepository bookingRepo;

	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	/**
	 * Register a new user
	 * 
	 * @param customer
	 * @return
	 */
	@PostMapping("/register")
	public Customer register(@RequestBody Customer customer) {
		logger.trace("In register Customer Controller");
		customerService.register(customer);
		return customer;
	}

	/**
	 * Get all cities
	 * 
	 * @param customer
	 * @return List of City
	 */

	@GetMapping("/getCities")
	public List<City> getCityList() {
		logger.trace("getCities from Customer Controller");
		return customerService.getCityList();
	}

	/**
	 * Returns a Map of available rooms based on checkIn, checkOut and city
	 * 
	 * @param checkin
	 * @param checkout
	 * @param cityName
	 * @return
	 */
	@GetMapping("/availablerooms")
	public ResponseEntity<?> availableRooms(@RequestParam("checkIn") String checkIn,
			@RequestParam("checkOut") String checkOut, @RequestParam("cityId") long cityId) {

		try {
			LocalDate localDateCheckIn = LocalDate.parse(checkIn);
			LocalDate localDateCheckOut = LocalDate.parse(checkOut);
			logger.trace("In availableRooms function");
			if (Validate.validateCheckInCheckOutDate(localDateCheckIn, localDateCheckOut)) {
				logger.trace("Successfully validated Date");
				return new ResponseEntity<List<Hotel>>(
						customerService.availableRooms(localDateCheckIn, localDateCheckOut, cityId), HttpStatus.OK);

			} else
				throw new HotelException("Enter valid date");
		} catch (Exception e) {
			logger.trace("Expection caught in availableRooms(), Customer Controller");
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * 
	 * @param checkIn
	 * @param checkOut
	 * @param cityId
	 * @param hotelId
	 * @param roomId
	 * @return
	 */

	@PostMapping("/makebooking")
	public ResponseEntity<?> makeBooking(@RequestParam("username") String username,
			@RequestParam("password") String password, @RequestParam("checkIn") String checkIn,
			@RequestParam("checkOut") String checkOut, @RequestParam("cityId") long cityId,
			@RequestParam("hotelId") long hotelId, @RequestParam("roomId") long roomId) {
		logger.trace("In makeBooking()");
		try {

			Room room = adminService.viewSingleRoom(roomId);
			LocalDate localDateCheckIn = LocalDate.parse(checkIn);
			LocalDate localDateCheckOut = LocalDate.parse(checkOut);

			Booking booking = new Booking(localDateCheckIn, localDateCheckOut, room, 0);
			if (customerService.isAvailable(room, localDateCheckIn, localDateCheckOut)) {

				Customer customer = customerService.getCustomer("avantika", "12345");

				if (customer.getBooking() != null) {
					throw new Exception("Only 1 booking per customer allowed.");
				}
				customer.setBooking(booking);
				customerRepo.save(customer);
				long bookingId = customer.getBooking().getBookingId();
				booking.setBookingId(bookingId);

			}

			return new ResponseEntity<Booking>(booking, HttpStatus.OK);
		} catch (Exception e) {
			logger.trace("Exception caught in makeBooking()");
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Cancel Booking
	 * 
	 * @param bookingId
	 * @return boolean
	 */

	@PostMapping("/cancelbooking")
	public boolean cancelBooking(@RequestParam("bookingId") Long bookingId) {
		logger.trace("In cancelBooking()");
		try {
			customerService.cancelBooking(bookingId);
		} catch (Exception e) {
		}
		return true;
	}

}

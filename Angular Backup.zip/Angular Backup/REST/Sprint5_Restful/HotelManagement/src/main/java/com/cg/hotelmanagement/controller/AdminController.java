package com.cg.hotelmanagement.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.hotelmanagement.dto.City;
import com.cg.hotelmanagement.dto.Customer;
import com.cg.hotelmanagement.dto.Hotel;
import com.cg.hotelmanagement.dto.Room;
import com.cg.hotelmanagement.exception.HotelException;
import com.cg.hotelmanagement.service.ExcelGenerator;
import com.cg.hotelmanagement.service.IAdminService;
import com.cg.hotelmanagement.service.ICustomerService;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {

	@Autowired
	IAdminService adminService;
	@Autowired
	ICustomerService customerService;

	Long cityID = null;
	Long hotelID = null;

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	// ----------------------City--------------------------

	/**
	 * Show all cities
	 * 
	 * @return
	 * @throws HotelException
	 */
	@GetMapping("/cities")
	public ResponseEntity<List<City>> getCities() {
		logger.info("getCities in Controller");
		List<City> cityList = adminService.showCity();
		if (cityList.size() == 0) {
			logger.info("No cities present");
			return new ResponseEntity<List<City>>(HttpStatus.NO_CONTENT);
		} else {
			logger.info("Returning city list");
			return new ResponseEntity<List<City>>(cityList, HttpStatus.OK);
		}
	}

	/**
	 * Find city by cityId
	 * 
	 * @param cityId
	 * @return
	 */
	@GetMapping("/cities/{cityId}")
	public City getCity(@PathVariable long cityId) {
		logger.trace("getCity in Controller");
		return adminService.findCityById(cityId);
	}

	/**
	 * Add city
	 * 
	 * @param city
	 * @return
	 */
	@PostMapping("/cities")
	public ResponseEntity<?> addCity(@RequestBody City city) {
		logger.info("City added in Controller");
		return new ResponseEntity<City>(adminService.addCity(city), HttpStatus.OK);
	}

	/**
	 * Delete city by cityId
	 */
	@DeleteMapping("/cities/{cityId}")
	public ResponseEntity<?> deleteCity(@PathVariable long cityId) {

		adminService.removeCity(cityId);
		logger.trace("deleteCity in Controller");
		return new ResponseEntity<String>("City with Id: " + cityId + " deleted", HttpStatus.OK);
	}

	/**
	 * Download excel
	 * 
	 * @return File
	 * @throws IOException
	 */
	@GetMapping("/cities/download/cities.xlsx")
	public ResponseEntity<InputStreamResource> downloadCity() throws IOException {
		List<City> cityList = customerService.getCityList();

		ByteArrayInputStream in = ExcelGenerator.customersToExcel(cityList);
		// return IOUtils.toByteArray(in);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=customers.xlsx");
		logger.trace("Download");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	/**
	 * Upload file
	 * 
	 * @param reapExcelDataFile
	 * @throws IOException
	 */
	@PostMapping("/upload/city")
	public void uploadCity(@RequestParam("file") MultipartFile reapExcelDataFile) throws IOException {

		XSSFWorkbook workbook = new XSSFWorkbook(reapExcelDataFile.getInputStream());
		XSSFSheet worksheet = workbook.getSheetAt(0);

		for (int i = 1; i < worksheet.getPhysicalNumberOfRows(); i++) {
			City tempCity = new City();

			XSSFRow row = worksheet.getRow(i);

			tempCity.setCityName(row.getCell(0).getStringCellValue());
			adminService.addCity(tempCity);
			workbook.close();

		}
	}

	// ----------------------Hotel--------------------------

	/**
	 * Get all hotels in a city
	 * 
	 * @param cityId
	 * @return
	 */
	@GetMapping("/hotels/{cityId}")
	public ResponseEntity<List<Hotel>> getHotels(@PathVariable long cityId) {
		logger.info("getHotels in Controller");
		List<Hotel> hotelList = adminService.showHotels(cityId);
		if (hotelList.size() == 0) {
			logger.info("No hotels present in city with Id: " + cityId);
			return new ResponseEntity<List<Hotel>>(HttpStatus.NO_CONTENT);
		} else {
			logger.info("Returning hotel list");
			return new ResponseEntity<List<Hotel>>(hotelList, HttpStatus.OK);
		}
	}

	/**
	 * Find a hotel using hotelId
	 * 
	 * @param hotelId
	 * @return
	 */
	@GetMapping("/hotels")
	public Hotel getHotel(@RequestParam long hotelId) {
		logger.trace("getHotel in Controller");
		return adminService.viewSingleHotel(hotelId);
	}

	/**
	 * Find hotel by Id
	 * 
	 * @param cityId
	 * @param hotel
	 * @return
	 * @throws HotelException
	 */
	@PostMapping("/hotels")
	public ResponseEntity<Hotel> addHotel(@RequestParam("cityId") long cityId, @RequestBody Hotel hotel) {
		adminService.addHotel(cityId, hotel);
		logger.trace("addHotel in Controller");
		return new ResponseEntity<Hotel>(hotel, HttpStatus.OK);
	}

	/**
	 * Add hotel
	 * 
	 * @param hotelId
	 * @param hotel
	 * @return
	 */
	@PutMapping("/hotels")
	public ResponseEntity<Hotel> updateHotel(@RequestParam("hotelId") long hotelId, @RequestBody Hotel hotel) {
		adminService.updateHotel(hotelId, hotel);
		logger.trace("updateHotel in Controller");
		return new ResponseEntity<Hotel>(hotel, HttpStatus.OK);
	}

	/**
	 * Delete hotel
	 * 
	 * @param hotelId
	 * @return
	 */
	@DeleteMapping("/hotels/{hotelId}")
	public ResponseEntity<?> deleteHotel(@PathVariable long hotelId) {
		logger.info("deleteHotel in Controller");
		return new ResponseEntity<String>("Hotel deleted with Id: " + hotelId, HttpStatus.OK);
	}

	// ----------------------Room--------------------------

	/**
	 * Get all rooms in a given city and hotel
	 * 
	 * @param cityId
	 * @param hotelId
	 * @return
	 */
	@GetMapping("/rooms")
	public ResponseEntity<List<Room>> getRooms(@RequestParam("cityId") long cityId,
			@RequestParam("hotelId") long hotelId) {
		logger.trace("getRooms in Controller");
		List<Room> roomList = adminService.showRooms(cityId, hotelId);
		if (roomList.size() == 0) {
			logger.info("No rooms found");
			return new ResponseEntity<List<Room>>(HttpStatus.NO_CONTENT);
		} else {
			logger.info("Getting rooms");
			return new ResponseEntity<List<Room>>(roomList, HttpStatus.OK);
		}
	}

	/**
	 * Find room by Id
	 * 
	 * @param roomId
	 * @return
	 */
	@GetMapping("/rooms/{roomId}")
	public Room getRoom(@PathVariable long roomId) {
		logger.trace("getRoom in Controller");
		return adminService.viewSingleRoom(roomId);
	}

	/**
	 * Add room
	 * 
	 * @param cityId
	 * @param hotelId
	 * @param room
	 * @return
	 */
	@PostMapping("/rooms")
	public ResponseEntity<Room> addRoom(@RequestParam("cityId") long cityId, @RequestParam("hotelId") long hotelId,
			@RequestBody Room room) {
		logger.trace("addRoom in Controller");
		return new ResponseEntity<Room>(adminService.addRoom(cityId, hotelId, room), HttpStatus.OK);
	}

	/**
	 * Update room
	 * 
	 * @param roomId
	 * @param room
	 * @return
	 */
	@PutMapping("/rooms")
	public ResponseEntity<?> updateRoom(@RequestParam("roomId") long roomId, @RequestBody Room room) {

//		adminService.updateHotel(hotelId, hotel);
//		logger.trace("updateHotel in Controller");
//		return new ResponseEntity<Hotel>(hotel,HttpStatus.OK);

		adminService.updateRoom(roomId, room);
		logger.info("Room updated");
		return new ResponseEntity<String>("Room updated with Id: " + roomId, HttpStatus.OK);
	}

	/**
	 * Delete room
	 * 
	 * @param roomId
	 * @return
	 */
	@DeleteMapping("rooms/{roomId}")
	public ResponseEntity<?> deleteRoom(@PathVariable long roomId) {
		logger.trace("deleteRoom in Controller");
		return new ResponseEntity<String>("Room deleted with Id: " + roomId, HttpStatus.OK);
	}

	@GetMapping("/finduser")
	public ResponseEntity<?> findUser(@RequestParam("userEmail") String userEmail) {
		try {
			logger.info("Fetching user object linked with user Email..");
			Customer customer = adminService.findUser(userEmail);
//			System.out.println(customer.toString());
			return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		} catch (HotelException exception) {
			logger.info("HotelException caught in find user controller..");
			return new ResponseEntity<String>(exception.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

}

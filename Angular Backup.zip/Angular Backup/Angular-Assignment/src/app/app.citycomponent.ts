import { Component , OnInit, OnChanges, OnDestroy } from "@angular/core";
import {HmsService} from './service/app.hmsservice'
import {City}from './_model/app.city'


@Component({selector:'city',
templateUrl:'app.city.html'
}
)


export class CityComponent {
    modelCity:any = {};
    status:boolean=true;
    errorMessage:String="";
constructor(private service:HmsService){

    console.log("In constructor");
}


addCity():any
{
   
    this.service.addCity(this.modelCity).subscribe((data)=>console.log(data),
    error=>this.errorMessage=error.error);

}

validate():any{

    if(this.modelCity.cityName!='' && this.modelCity.cityName.match("[a-zA-Z\\s]")){
        this.status=false;
        console.log("1");
    }
    else{
        this.status=true;
    }
        
    
}



}


import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';


@Injectable({
    providedIn:'root'
})
export class CustomerService{

    constructor(private myhttp:HttpClient){}

    /**
     * @returns List of Cities
     */
    getCityList(){
        console.log("ok")
        return this.myhttp.get("http://localhost:9088//customer//getCities");
    }

    /**
     * 
     * @param checkInDate 
     * @param checkOutDate 
     * @param cityId 
     * @returns List of Hotels with available Rooms
     */
    viewAvailableRooms(checkInDate,checkOutDate,cityId){
        return this.myhttp.get("http://localhost:9088/customer/availablerooms?checkIn="+
        checkInDate+"&checkOut="+checkOutDate+"&cityId="+cityId)
    }

    /**
     * 
     * @param checkIn 
     * @param checkOut 
     * @param cityId 
     * @param hotelId 
     * @param roomId 
     * @returns Booking object
     */
    makeBooking(checkIn,checkOut,cityId,hotelId,roomId)
    {
        
        return this.myhttp.post("http://localhost:9088/customer/makebooking?username=avantika&password=12345&checkIn="+checkIn+"&checkOut="+checkOut+"&cityId="+cityId+"&hotelId="+hotelId+"&roomId="+roomId,null);
    
    }

    /**
     * Cancels booking
     * @param bookingId 
     * @returns boolean
     */
    cancelBooking(bookingId)
    {
        return this.myhttp.post("http://localhost:9088/customer/cancelbooking?bookingId="+bookingId,null);
    }

}
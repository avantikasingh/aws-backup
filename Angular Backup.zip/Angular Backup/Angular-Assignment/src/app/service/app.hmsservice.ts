import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
    providedIn: 'root'

})
export class HmsService {
    constructor(private myhttp: HttpClient) {
    }



    addCity(data: any) {
      alert("City Added");
        return this.myhttp.post("http://localhost:9088/admin/cities", data);
    }

    deleteCity(data: any) {

         alert("City Deleted, Please Refresh");
        return this.myhttp.delete("http://localhost:9088/admin/cities/"+data);
    }

    getCities() {
        return this.myhttp.get("http://localhost:9088/admin/cities");
    }



    addHotel(data: any, cityId: any) {
        alert("Hotel Added");
        return this.myhttp.post("http://localhost:9088/admin/hotels?cityId=" + cityId, data);
    }

    updateHotel(data: any, hotelId: any) {
        alert("Hotel Updated , Please Refresh");
        return this.myhttp.put("http://localhost:9088/admin/hotels?hotelId=" + hotelId, data);
    }

    deleteHotel(hotelId: any) {
        alert("Hotel Deleted , Please Refresh");
        return this.myhttp.delete("http://localhost:9088/admin/hotels/" + hotelId);
    }

    getHotels(cityId) {
        return this.myhttp.get("http://localhost:9088/admin/hotels/" + cityId);
    }



    addRoom(data: any, cityId: any, hotelId: any) {
        alert("Room Added");
        return this.myhttp.post("http://localhost:9088/admin/rooms?cityId=" + cityId + "&hotelId=" + hotelId, data);
    }

    updateRoom(data: any, roomId: any) {
        alert("Room Updated , Please Refresh");
        return this.myhttp.put("http://localhost:9088/admin/rooms?roomId=" + roomId, data);
    }


    deleteRoom(roomId: any) {
        alert("Room Deleted , Please Refresh");
        return this.myhttp.delete("http://localhost:9088/admin/rooms/" + roomId);
    }

    getRooms(hotelId, cityId) {
        return this.myhttp.get("http://localhost:9088/admin/rooms?cityId=" + cityId + "&hotelId=" + hotelId);
    }



    getAllData() {
        return this.myhttp.get("http://localhost:9088/product/getall");
    }


    getUser(useremail:any){
        return this.myhttp.get("http://localhost:9088/admin/finduser?userEmail="+useremail);
    }

    addProduct(data: any) {

        let form = new FormData();
        form.append("prodId", data.prodId);
        form.append("prodName", data.prodName);
        form.append("prodCost", data.prodCost);
        form.append("prodDescription", data.prodDescription);
        // return this.myhttp.post("http://192.168.0.161:9088/product/add", data);
        return this.myhttp.post("http://localhost:9088/product/add", form);
    }
    deleteProduct(i) {

        return this.myhttp.delete("http://localhost:9088/product/delete?id=" + i);
    }


    register(data:any){
        return this.myhttp.post("http://localhost:9088/register",data);
    }




    authenticate(username:string, password:string) {
        console.log("Inside service authenticate.. email: "+username+" password: "+password);
        const reqbody={emailId: username, password:password};
        console.log(JSON.stringify(reqbody))
        
        return this.myhttp.post<any>('http://localhost:9088/authenticate', {emailId: username, password:password});
      }

    isUserLoggedIn() {
        let user = sessionStorage.getItem('username')
        console.log(!(user === null))
        return !(user === null)
    }

    logOut() {
        sessionStorage.removeItem('username');
        sessionStorage.removeItem('token');
        sessionStorage.removeItem('userId');
        sessionStorage.removeItem('role');
       
    }

}
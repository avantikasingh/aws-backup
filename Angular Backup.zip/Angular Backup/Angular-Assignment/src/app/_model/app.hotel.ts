import { Room } from "./app.room";

export class Hotel{
//    createdBy: any;
// createdDate: any;
// deleteFlag: any;
hotelAddress: string;
hotelId: number;
hotelName: string;
hotelPhoneNumber: string;
hotelRating: number;
// modifiedBy: any;
// modifiedDate: any;
roomList:Room[];
}
export class CustomerModel{
    userId:any;
    username:any;
    emailId:any;
    userMobile:any;
    firstName:any;
    lastName:any;
    aadharNumber:any;
    password:any;
    role:any;
}
import { Component} from '@angular/core';
import { LocationStrategy } from '@angular/common';

@Component({
    selector: 'adminhome',
    templateUrl: 'app.adminhome.html'
})

export class AdminComponent  {
}

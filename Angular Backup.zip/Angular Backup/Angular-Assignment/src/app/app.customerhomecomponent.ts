import { Component , OnInit} from "@angular/core";
import { CustomerService } from "./service/app.customerservice";
import { City } from "./_model/app.city";
import { Hotel } from "./_model/app.hotel";
import { Booking } from "./_model/app.booking";
import { DatePipe} from "@angular/common";





@Component({
    selector:"customerhomecomponent,",
    templateUrl:"app.customerhomecomponent.html",
})


export class CustomerHomeComponent{

    homePage:boolean
    viewHotelPage:boolean
    checkInDate:any
    checkOutDate:any
    cityName:any
    cityId:any
    cityList:City[]=[];
    hotelList:Hotel[]=[];
    booking:Booking=null;
    bookingPage: boolean;
    todayDate=this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    
    constructor(private service:CustomerService,private datePipe: DatePipe){
    }

    /*Sets boolean values of div components and gets City list from Spring Rest */

    ngOnInit(){
        this.homePage=true;
        this.viewHotelPage=false;
        this.bookingPage=false;
        this.service.getCityList().subscribe((data:City[])=>this.cityList=data);
    }

    /*Gets available Hotels and Rooms from Spring Rest */
    viewHotels(cityName):any
    {
        this.homePage=false;
        this.viewHotelPage=true;
        for(var x=0;x<this.cityList.length;x++)
        {
            if(this.cityList[x].cityName==cityName)
            {
                this.cityId=this.cityList[x].cityId;
            }
        }

        this.service.viewAvailableRooms(this.checkInDate,this.checkOutDate,this.cityId).subscribe(
            (data:Hotel[])=>this.hotelList=data,error=>{alert(error.error);this.homePage=true;this.viewHotelPage=false});
        
    }
    
   /**Calls make booking function from service */
    makeBooking(i,j)
    {
        console.log(this.hotelList)
        this.viewHotelPage=false;
        this.bookingPage=true;
       this.service.makeBooking(this.checkInDate,this.checkOutDate,this.cityId,this.hotelList[i].hotelId,this.hotelList[i].roomList[j].roomId).
       subscribe((data:Booking)=>this.booking=data,error=>{alert(error.error);this.viewHotelPage=true;this.bookingPage=false;});
    
    }

    /*Calls cancelBooking Function from service */
    cancelBooking(bookingId:any)
    {
        this.bookingPage=false;
        this.homePage=true;
        this.service.cancelBooking(bookingId).subscribe();
        alert("Booking Cancelled Successfully!");
    }

}


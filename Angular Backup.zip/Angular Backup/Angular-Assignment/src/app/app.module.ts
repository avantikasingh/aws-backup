﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatExpansionModule, MatInputModule, MatCardModule, MatButtonModule, MAT_DIALOG_DEFAULT_OPTIONS} from '@angular/material'

import { DatePipe } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { HotelComponent } from './app.hotelcomponent';
import { RoomComponent } from './app.roomcomponent';
import { AboutUsComponent } from './app.aboutuscomponent';
import { ShowCityComponent } from './app.showcitycomponent';
import { ShowHotelComponent } from './app.showhotelcomponent';
import { ShowRoomComponent } from './app.showroomcomponent';
import { AdminComponent } from './app.adminhomecomponent';
import { CustomerHomeComponent } from './app.customerhomecomponent';

import { RegisterComponent } from './app.registercomponent';
import {FileUploadModule} from 'ng2-file-upload';
import { CityComponent } from './app.citycomponent';
import { ExcelUploadComponent } from './app.exceluploadcomponent';

import { LoginComponent } from './app.login';

const myroute: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'about', component: AboutUsComponent },
    { path: 'login', component: LoginComponent },
    { path: 'addcity', component: CityComponent },
    { path: 'showcity', component: ShowCityComponent },
    { path: 'addhotel', component: HotelComponent },
    { path: 'showhotel', component: ShowHotelComponent },
    { path: 'addroom', component: RoomComponent },
    { path: 'showroom', component: ShowRoomComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'adminhome', component: AdminComponent },
    { path: 'excelupload', component: ExcelUploadComponent },
    { path: 'customerhomecomponent', component: CustomerHomeComponent }
]

@NgModule({
    imports: [
        BrowserModule, FormsModule, HttpClientModule, BrowserAnimationsModule,
        MatExpansionModule, MatInputModule, MatCardModule, MatButtonModule, FileUploadModule,
        RouterModule.forRoot(myroute)
        
    ],
    declarations: [
        AppComponent,AdminComponent, CustomerHomeComponent, 
        CustomerHomeComponent, AboutUsComponent, ShowCityComponent, ShowHotelComponent, 
        ShowRoomComponent, CityComponent,LoginComponent, HotelComponent, RoomComponent, RegisterComponent, ExcelUploadComponent
		],
    providers: [ DatePipe,  {provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: {hasBackdrop: false}}],
    
    bootstrap: [AppComponent]
})

export class AppModule { }
import { Component } from "@angular/core";
// import { Component , OnInit, OnChanges, OnDestroy } from "@angular/core";
import {HmsService} from './service/app.hmsservice'


@Component({selector:'aboutus',
templateUrl:'app.aboutus.html'})
export class AboutUsComponent {

}